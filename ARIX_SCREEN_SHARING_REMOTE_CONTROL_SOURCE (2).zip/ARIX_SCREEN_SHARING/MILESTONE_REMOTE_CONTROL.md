# ARIX Screen Sharing — Milestone 6 (Remote Control Preview)

## Included in this source build
- Browser creates a WebRTC data channel with the Android sender.
- The computer can request control; Android posts a notification and requires a separate phone-side review.
- Tap, scroll and text insertion are accepted only after explicit phone approval and only while the peer connection is live.
- Android Accessibility Service is opt-in and must be enabled manually in Android Settings. Text is inserted only into the currently focused editable field.
- Control is revoked when the peer disconnects, renegotiates, or screen sharing stops. The Android foreground notification keeps a Stop sharing action.
- WebRTC data channels use DTLS encryption in transit. The existing WebRTC video track uses DTLS-SRTP. Signaling uses WSS when the hosted site is HTTPS. This is not an independently audited E2EE/security certification.

## Important test status
This source has not yet been compiled or tested on a physical Android device. Test the generated APK on your own phone before relying on remote control. Verify that deny works, approval works, the Stop button revokes control, and disconnect revokes control.

## Limitations
- Remote text input uses Android Accessibility `ACTION_SET_TEXT` on the focused editable node; it is not arbitrary hardware-key injection.
- Some apps intentionally block accessibility interaction or screen capture.
- Tap coordinates and scrolling need calibration across different aspect ratios and display scaling.
- Receiver feedback adjusts the video sender bitrate within the selected quality preset. Capture resolution and frame rate still use the selected preset; adaptive resolution/FPS is not implemented yet.
- TURN configuration is still needed for reliable connections across restrictive networks.


## Encryption status
- The WebRTC media track is protected by DTLS-SRTP and the peer-to-peer control DataChannel is protected by DTLS.
- Hosted signaling uses WSS. The signaling service relays session setup metadata (including SDP/ICE); it does not decrypt the WebRTC media or DataChannel payloads.
- This is encrypted peer-to-peer transport, but it is not a claim of independently audited end-to-end identity assurance. A stronger E2EE design requires authenticated device identity/fingerprint verification and key-change warnings before trusting a peer. Do not describe the app as certified or audited E2EE until that design is implemented and independently reviewed.
