package com.arix.screenshare

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Pairing + control screen. All state about an active share lives in [ShareState] (written by the service),
 * so rotating the phone or reopening the app never loses it.
 */
class MainActivity : ComponentActivity() {
    private val http = OkHttpClient.Builder().callTimeout(10, TimeUnit.SECONDS).build()
    private val ui = Handler(Looper.getMainLooper())
    private var createCall: Call? = null

    private lateinit var serverInput: EditText
    private lateinit var qualitySpinner: Spinner
    private lateinit var generate: Button
    private lateinit var codeView: TextView
    private lateinit var expiryView: TextView
    private lateinit var start: Button
    private lateinit var stop: Button
    private lateinit var notifSettings: Button
    private lateinit var status: TextView

    private var localMessage: String? = null     // messages that are not part of ShareState (e.g. HTTP errors)
    private var creating = false                 // a /api/session request is in flight
    private var quality = Quality.BALANCED

    private val stateListener = Runnable { render() }
    private val tick = object : Runnable {
        override fun run() {
            render()
            ui.postDelayed(this, 1000)
        }
    }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted || notificationsEnabled()) requestScreenCapture() else showNotificationsBlocked()
        }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            val pending = ShareState.pending
            if (result.resultCode == Activity.RESULT_OK && data != null && pending != null && !pending.expired()) {
                val intent = Intent(this, ScreenShareService::class.java).apply {
                    action = ScreenShareService.ACTION_START
                    putExtra(ScreenShareService.EXTRA_SERVER, pending.server)
                    putExtra(ScreenShareService.EXTRA_CODE, pending.code)
                    putExtra(ScreenShareService.EXTRA_TOKEN, pending.senderToken)
                    putExtra(ScreenShareService.EXTRA_QUALITY, quality.name)
                    putExtra(ScreenShareService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(ScreenShareService.EXTRA_PROJECTION_DATA, data)   // single-use consent token: never stored
                }
                ShareState.set(ShareState.Phase.CONNECTING, "Starting…")
                ContextCompat.startForegroundService(this, intent)
                localMessage = null
            } else if (result.resultCode != Activity.RESULT_OK) {
                localMessage = "Screen capture permission was not granted. Nothing is being shared."
            } else {
                localMessage = "The pairing code expired. Generate a new code."
            }
            render()
        }

    private val gold = Color.rgb(222, 181, 91)
    private val bg = Color.rgb(9, 9, 10)
    private val panel = Color.rgb(21, 20, 18)
    private val muted = Color.rgb(173, 166, 151)

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun rounded(color: Int, stroke: Int = Color.TRANSPARENT): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(16).toFloat()
            if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
        }

    private fun styleButton(button: Button, primary: Boolean) {
        button.isAllCaps = false
        button.textSize = 14f
        button.typeface = android.graphics.Typeface.DEFAULT_BOLD
        button.setTextColor(if (primary) Color.rgb(24, 19, 10) else gold)
        button.background = rounded(if (primary) gold else Color.rgb(35, 31, 23), if (primary) gold else Color.rgb(91, 72, 37))
        button.minHeight = dp(50)
        button.elevation = dp(2).toFloat()
        button.setPadding(dp(16), dp(10), dp(16), dp(10))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        val prefs = getSharedPreferences("arix", Context.MODE_PRIVATE)
        val pad = dp(20)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(18), pad, dp(28))
            setBackgroundColor(bg)
        }

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val logo = text("A", 30f, gold, true).apply {
            gravity = android.view.Gravity.CENTER
            background = rounded(Color.rgb(37, 30, 17), gold)
            setPadding(dp(12), dp(3), dp(12), dp(3))
        }
        brandRow.addView(logo, LinearLayout.LayoutParams(dp(52), dp(52)))
        val brandText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            addView(text("ARIX", 21f, Color.WHITE, true))
            addView(text("SCREEN SHARING", 10f, gold, true))
        }
        brandRow.addView(brandText)
        root.addView(brandRow)

        val intro = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, Color.rgb(57, 47, 29))
            setPadding(dp(18), dp(20), dp(18), dp(20))
        }
        val pill = text("  YOUR SCREEN. YOUR CONTROL.  ", 10f, gold, true)
        intro.addView(pill)
        val title = text("Share your screen.", 26f, Color.WHITE, true)
        title.setPadding(0, dp(12), 0, dp(5))
        intro.addView(title)
        intro.addView(text("Connect your Android phone to a computer you control. You stay in charge of every sharing session.", 13f, muted))
        val secureNote = text("●  Screen capture always requires Android permission", 11f, gold)
        secureNote.setPadding(0, dp(14), 0, 0)
        intro.addView(secureNote)
        val introParams = LinearLayout.LayoutParams(-1, -2)
        introParams.topMargin = dp(22)
        root.addView(intro, introParams)

        val toolsTitle = text("TOOLS", 11f, gold, true)
        toolsTitle.setPadding(dp(2), dp(24), 0, dp(10))
        root.addView(toolsTitle)

        val toolCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, Color.rgb(66, 54, 33))
            setPadding(dp(16), dp(15), dp(16), dp(15))
        }
        val toolTop = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val monitor = text("▣", 25f, gold, true)
        toolTop.addView(monitor)
        val toolName = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            addView(text("Screen Sharing", 16f, Color.WHITE, true))
            addView(text("Phone → Computer", 11f, muted))
        }
        toolTop.addView(toolName, LinearLayout.LayoutParams(0, -2, 1f))
        toolTop.addView(text("ACTIVE TOOL", 9f, gold, true))
        toolCard.addView(toolTop)
        val toolDesc = text("Create a private pairing code, then approve the Android screen-capture prompt.", 12f, muted)
        toolDesc.setPadding(0, dp(12), 0, 0)
        toolCard.addView(toolDesc)
        root.addView(toolCard)

        val connectionTitle = text("CONNECTION", 11f, gold, true)
        connectionTitle.setPadding(dp(2), dp(22), 0, dp(8))
        root.addView(connectionTitle)

        serverInput = EditText(this).apply {
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            textSize = 14f
            hint = "https://your-server.example"
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.rgb(27, 26, 24), Color.rgb(75, 65, 46))
            setText(prefs.getString("server", "https://arix-screen-sharing.onrender.com"))
        }
        root.addView(text("Server address", 12f, muted))
        val serverParams = LinearLayout.LayoutParams(-1, -2)
        serverParams.topMargin = dp(6)
        root.addView(serverInput, serverParams)

        val qualityLabel = text("Streaming quality", 12f, muted)
        qualityLabel.setPadding(0, dp(14), 0, dp(5))
        root.addView(qualityLabel)
        qualitySpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, Quality.values().map { it.label })
            quality = Quality.fromName(prefs.getString("quality", null))
            setSelection(quality.ordinal)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    quality = Quality.values()[position]
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        root.addView(qualitySpinner)

        generate = Button(this).apply { text = "Generate pairing code"; styleButton(this, true) }
        val generateParams = LinearLayout.LayoutParams(-1, -2)
        generateParams.topMargin = dp(16)
        root.addView(generate, generateParams)

        val codePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            background = rounded(Color.rgb(27, 25, 20), Color.rgb(111, 86, 43))
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        codePanel.addView(text("YOUR PAIRING CODE", 10f, gold, true))
        codeView = text("------", 34f, Color.WHITE, true).apply {
            letterSpacing = 0.18f
            setPadding(0, dp(3), 0, 0)
        }
        codePanel.addView(codeView)
        expiryView = text("Generate a code to begin", 11f, muted)
        codePanel.addView(expiryView)
        val codeParams = LinearLayout.LayoutParams(-1, -2)
        codeParams.topMargin = dp(12)
        root.addView(codePanel, codeParams)

        start = Button(this).apply { text = "Approve & start screen sharing"; styleButton(this, false) }
        val startParams = LinearLayout.LayoutParams(-1, -2)
        startParams.topMargin = dp(12)
        root.addView(start, startParams)

        stop = Button(this).apply {
            text = "Stop sharing"
            styleButton(this, false)
            setTextColor(Color.rgb(255, 130, 120))
            background = rounded(Color.rgb(47, 24, 22), Color.rgb(125, 52, 44))
        }
        val stopParams = LinearLayout.LayoutParams(-1, -2)
        stopParams.topMargin = dp(8)
        root.addView(stop, stopParams)

        notifSettings = Button(this).apply { text = "Open notification settings"; styleButton(this, false); visibility = View.GONE }
        root.addView(notifSettings)

        status = text("Ready when you are. Generate a pairing code to connect.", 12f, muted)
        status.setPadding(dp(2), dp(16), dp(2), dp(8))
        root.addView(status)

        val safety = text("Only share your pairing code with your own computer. Android permission and the visible Stop control remain required for every session.", 11f, Color.rgb(132, 127, 116))
        safety.setPadding(dp(2), dp(10), dp(2), 0)
        root.addView(safety)

        root.addView(text("ARIX AI CODER  •  BUILT FOR CONTROL", 9f, Color.rgb(112, 103, 84)).apply {
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(28), 0, 0)
        })

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            fitsSystemWindows = true
            setBackgroundColor(bg)
            addView(root)
        })

        generate.setOnClickListener { createSession(prefs.edit()) }
        start.setOnClickListener { beginShare(prefs.edit()) }
        stop.setOnClickListener {
            startService(Intent(this, ScreenShareService::class.java).setAction(ScreenShareService.ACTION_STOP))
        }
        notifSettings.setOnClickListener {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
    }

    override fun onStart() {
        super.onStart()
        ShareState.addListener(stateListener)
        ui.post(tick)
    }

    override fun onStop() {
        ui.removeCallbacks(tick)
        ShareState.removeListener(stateListener)
        super.onStop()
    }

    override fun onDestroy() {
        if (isFinishing) createCall?.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------ actions
    private fun createSession(prefs: android.content.SharedPreferences.Editor) {
        when (val addr = ServerAddress.normalize(serverInput.text.toString())) {
            is ServerAddress.Result.Bad -> { localMessage = addr.message; render() }
            is ServerAddress.Result.Ok -> {
                prefs.putString("server", addr.base).putString("quality", quality.name).apply()
                serverInput.setText(addr.base)
                localMessage = "Contacting the server…"
                creating = true
                render()
                val request = Request.Builder().url("${addr.base}/api/session").post(ByteArray(0).toRequestBody(null)).build()
                createCall = http.newCall(request)
                createCall!!.enqueue(object : Callback {
                    override fun onFailure(call: Call, e: IOException) {
                        runOnUiThread { localMessage = "Could not reach the server: ${e.message}"; creating = false; render() }
                    }

                    override fun onResponse(call: Call, response: Response) {
                        response.use {
                            val body = it.body?.string().orEmpty()
                            val message: String? = when {
                                it.code == 429 -> "Too many codes requested. Wait a minute and try again."
                                !it.isSuccessful -> "Server refused to create a code (HTTP ${it.code})."
                                else -> try {
                                    val j = JSONObject(body)
                                    ShareState.pending = ShareState.Pending(
                                        addr.base, j.getString("code"), j.getString("sender_token"), j.optInt("expires_in", 300)
                                    )
                                    null
                                } catch (e: JSONException) {
                                    "The server's reply was not understood. Is this an ARIX server?"
                                }
                            }
                            runOnUiThread {
                                localMessage = message ?: "Code ready. Enter it on your computer, then approve screen capture."
                                creating = false
                                render()
                            }
                        }
                    }
                })
            }
        }
    }

    private fun beginShare(prefs: android.content.SharedPreferences.Editor) {
        prefs.putString("quality", quality.name).apply()
        val pending = ShareState.pending
        if (pending == null || pending.expired()) {
            localMessage = "Generate a new pairing code first."
            render()
            return
        }
        if (notificationsEnabled()) {
            requestScreenCapture()
        } else if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            showNotificationsBlocked()
        }
    }

    private fun requestScreenCapture() {
        // A fresh system consent dialog is ALWAYS shown; the result is never cached or reused.
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun notificationsEnabled() = NotificationManagerCompat.from(this).areNotificationsEnabled()

    private fun showNotificationsBlocked() {
        localMessage = "Notifications are turned off for ARIX. The sharing notification (with its Stop button) must be visible, so sharing was not started."
        render()
    }

    // ------------------------------------------------------------ rendering
    private fun render() {
        val active = ShareState.active
        val pending = ShareState.pending
        codeView.text = pending?.code?.chunked(3)?.joinToString(" ") ?: "------"
        expiryView.text = when {
            active || pending == null -> ""
            pending.expired() -> "Code expired. Generate a new one."
            else -> "Enter this code on the computer within %d:%02d".format(pending.remainingSec() / 60, pending.remainingSec() % 60)
        }
        generate.isEnabled = !active && !creating
        start.isEnabled = !active && pending != null && !pending.expired()
        stop.isEnabled = active
        stop.alpha = if (active) 1f else 0.4f
        notifSettings.visibility = if (!active && !notificationsEnabled() && localMessage?.startsWith("Notifications") == true) View.VISIBLE else View.GONE
        status.text = when {
            active -> ShareState.detail
            localMessage != null -> localMessage
            ShareState.lastEnded != null -> "Sharing ended. ${ShareState.lastEnded}"
            else -> "Generate a code, enter it on the computer, then approve screen capture."
        }
    }
}
