package com.arix.screenshare

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityEvent
import android.util.DisplayMetrics
import android.view.WindowManager

/** Opt-in Android accessibility bridge. Commands are accepted only while the sharing service has phone-side consent. */
class RemoteControlAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }

    fun tap(nx: Double, ny: Double): Boolean {
        if (nx !in 0.0..1.0 || ny !in 0.0..1.0) return false
        val (w, h) = screenSize()
        val px = (nx * w).toFloat(); val py = (ny * h).toFloat()
        val path = Path().apply { moveTo(px, py); lineTo(px + 1f, py + 1f) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 65)
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun scroll(nx: Double, ny: Double, down: Boolean): Boolean {
        if (nx !in 0.0..1.0 || ny !in 0.0..1.0) return false
        val (w, h) = screenSize()
        val x = (nx * w).toFloat(); val y = (ny * h).toFloat()
        val distance = (h * 0.22f).coerceAtLeast(120f)
        val path = Path().apply {
            moveTo(x, y)
            lineTo(x, (y + if (down) -distance else distance).coerceIn(2f, h - 2f))
        }
        return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 260)).build(), null, null)
    }

    fun insertText(value: String): Boolean {
        if (value.length > 500 || value.any { it == '\u0000' }) return false
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        if (!node.isEditable) return false
        val args = android.os.Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value) }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds; b.width() to b.height()
        } else {
            @Suppress("DEPRECATION")
            val dm = DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }; dm.widthPixels to dm.heightPixels
        }
    }

    companion object { @Volatile var instance: RemoteControlAccessibilityService? = null; private set }
}
